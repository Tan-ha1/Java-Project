package Interfaces;

import java.lang.*;
import Classes.*;

public interface iRegistrationOperation {
    void registration(String textField5, String textField6, String textField4, String textField8, String secQsna);
}
