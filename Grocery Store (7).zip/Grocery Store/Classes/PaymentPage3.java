package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Font;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Cursor;
import static javax.swing.JOptionPane.showMessageDialog;

public class PaymentPage3 {
    JFrame frame;
    JPanel paymentPanel;
    JLabel totalPriceLabel,l8;

    PaymentPage3(String textField1, ArrayList<String> selectedProducts, double totalPrice) {
        frame = new JFrame();
        frame.setUndecorated(true);

        paymentPanel = new JPanel();
        paymentPanel.setBounds(0, 0, 655, 768);
        paymentPanel.setBackground(new Color(25, 118, 211));
		
		//tp
		totalPrice = getTotalPrice(selectedProducts);

        totalPriceLabel = new JLabel("Total Price: BDT " + totalPrice);
        totalPriceLabel.setBounds(50, 50, 300, 40);
        totalPriceLabel.setFont(new Font("Serif", Font.BOLD, 20));
        totalPriceLabel.setForeground(Color.white);

        StringBuilder selectedProductsText = new StringBuilder();
        for (String product : selectedProducts) {
            selectedProductsText.append(product).append("<br>");
        }
        JLabel selectedProductsLabel = new JLabel("<html>Selected Products:<br>" + selectedProductsText + "</html>");
        selectedProductsLabel.setBounds(50, 100, 500, 200);
        selectedProductsLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        selectedProductsLabel.setForeground(Color.white);

        JButton backButton = new JButton("Pay Now");
        backButton.setBounds(50, 300, 150, 40);
        backButton.setFont(new Font("Serif", Font.BOLD, 20));
        backButton.setBackground(Color.orange);
        backButton.setForeground(Color.black);
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        frame.add(totalPriceLabel);
        frame.add(selectedProductsLabel);
        frame.add(backButton);
        frame.add(paymentPanel);

        frame.setSize(800, 500);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Payment(textField1);
                frame.setVisible(false);
            }
        });
		
		// HEadline
l8 = new JLabel("Pay as your cart");
l8.setBounds(300, 20, 300, 40);
l8.setFont(new Font("Serif", Font.BOLD, 24));
l8.setForeground(Color.black);

// Add the label to the panel, not the frame
paymentPanel.add(l8); 
    }
	 private double getTotalPrice(ArrayList<String> products) {
        double totalPrice = 0;
        for (String product : products) {
            int index = Integer.parseInt(product.substring(product.lastIndexOf(" ") + 1));
            switch (index) {
                case 1:
        totalPrice += 1990;
        break;
    case 2:
        totalPrice += 1200;
        break;
    case 3:
        totalPrice += 3500;
        break;
    case 4:
        totalPrice += 1900;
        break;
    case 5:
        totalPrice += 500;
        break;
    case 6:
        totalPrice += 13000;
        break;
    case 7:
        totalPrice += 3650;
        break;
    case 8:
        totalPrice += 15000;
            break;
                default:
                    
                  break;
            }
	}
	return totalPrice;
	 }
	 
}

