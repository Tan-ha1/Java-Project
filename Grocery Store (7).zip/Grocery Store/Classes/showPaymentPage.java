package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.util.*;
import java.awt.Cursor;
import static javax.swing.JOptionPane.showMessageDialog;

private void showPaymentPage() {
    // Create a new JPanel for payment page
    paymentPanel = new JPanel();
    paymentPanel.setLayout(new BoxLayout(paymentPanel, BoxLayout.Y_AXIS));

    // Add selected products to the payment panel
    for (String product : selectedProducts) {
        int index = Integer.parseInt(product.substring(product.lastIndexOf(" ") + 1)) - 1;
        JPanel productPanel = new JPanel();
        productPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        // Add product image
        JLabel productImageLabel = new JLabel(productIcons.get(index));
        productPanel.add(productImageLabel);

        JLabel productLabel = new JLabel(product);
        productLabels.add(productLabel);
        productPanel.add(productLabel);

        // Add product price label
        JLabel priceLabel = new JLabel("$" + getProductPrice(product));
        productPanel.add(priceLabel);

        paymentPanel.add(productPanel);
    }

    // Calculate total price
    totalPrice = getTotalPrice(selectedProducts);

    // Display total price
    totalPriceLabel = new JLabel("Total Price: $" + totalPrice);
    paymentPanel.add(totalPriceLabel);

    // Create a pay button
    payButton = new JButton("Pay");
    payButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Handle payment here
            // Redirect to another page
            redirectToPaymentConfirmationPage();
        }
    });
    paymentPanel.add(payButton);

    // Create a back button
    JButton backButton = new JButton("Back");
    backButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Handle back button action
            // For example, go back to the previous page
        }
    });
    paymentPanel.add(backButton);

    // Add the payment panel to a new JFrame
    JFrame paymentFrame = new JFrame("Payment Page");
    paymentFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    paymentFrame.getContentPane().add(paymentPanel);
    paymentFrame.pack();
    paymentFrame.setLocationRelativeTo(null);
    paymentFrame.setVisible(true);
}

private void redirectToPaymentConfirmationPage() {
    // Handle redirection to payment confirmation page
    // For example, create a new JFrame or JPanel to display payment confirmation
    // and close the current payment frame
}
