
//package Classes;
import Classes.*;
import Interfaces.*;
import java.lang.*;
import javax.swing.*;
import java.awt.event.*;

public class Start {

    public static void main(String[] args) {

        new Home();

    }
}